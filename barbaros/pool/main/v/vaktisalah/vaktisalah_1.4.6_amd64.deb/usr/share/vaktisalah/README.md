# Vakt-i Salah (Times of Prayer)
a Qt-Based Cross-Platform Prayer Times application.
*(Gets prayer times data from diyanet.gov.tr)*

![Photo 1](https://github.com/eminfedar/vaktisalah/raw/master/foto/1.3_1.png)
![Photo 2](https://github.com/eminfedar/vaktisalah/raw/master/foto/1.3_2.png)

## Download
You can download releases for these systems:
- Windows (.rar)
- Linux: [Flathub](https://flathub.org/apps/details/com.eminfedar.vaktisalah)

Go to the [releases page](https://github.com/eminfedar/vaktisalah/releases)
