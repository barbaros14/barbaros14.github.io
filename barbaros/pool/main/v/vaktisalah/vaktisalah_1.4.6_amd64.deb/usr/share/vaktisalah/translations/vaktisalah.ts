<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>MainForm.ui</name>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="150"/>
        <source>Sunrise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="159"/>
        <source>Isha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="169"/>
        <source>Maghrib</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="178"/>
        <source>Asr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="187"/>
        <source>Dhuhr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="196"/>
        <source>Fajr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="311"/>
        <source>Internet required to update times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="324"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="336"/>
        <source>Failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="365"/>
        <source>Gregorian:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="378"/>
        <source>Hijri:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="22"/>
        <source>Show / Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="26"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings.ui</name>
    <message>
        <location filename="../ui/Settings.ui.qml" line="28"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="82"/>
        <source>Background Opacity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="106"/>
        <source>District:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="141"/>
        <source>Warn before mins:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="152"/>
        <source>City:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="173"/>
        <source>Country:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="233"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="170"/>
        <source>to Fajr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="172"/>
        <source>to Sunrise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="174"/>
        <source>to Dhuhr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="176"/>
        <source>to Asr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="178"/>
        <source>to Maghrib</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="180"/>
        <source>to Isha</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
