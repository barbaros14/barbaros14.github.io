<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr_TR" sourcelanguage="en_US">
<context>
    <name>MainForm.ui</name>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="150"/>
        <source>Sunrise</source>
        <translation>Güneş</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="159"/>
        <source>Isha</source>
        <translation>Yatsı</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="169"/>
        <source>Maghrib</source>
        <translation>Akşam</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="178"/>
        <source>Asr</source>
        <translation>İkindi</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="187"/>
        <source>Dhuhr</source>
        <translation>Öğle</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="196"/>
        <source>Fajr</source>
        <translation>Sabah</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="311"/>
        <source>Internet required to update times.</source>
        <translation>Vakitleri güncellemek için internet gerekli.</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="324"/>
        <source>Update</source>
        <translation>Güncelle</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="336"/>
        <source>Failed!</source>
        <translation>Başarısız!</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="365"/>
        <source>Gregorian:</source>
        <translation>Miladi:</translation>
    </message>
    <message>
        <location filename="../ui/MainForm.ui.qml" line="378"/>
        <source>Hijri:</source>
        <translation>Hicri:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="22"/>
        <source>Show / Hide</source>
        <translation>Göster / Gizle</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="26"/>
        <source>Exit</source>
        <translation>Çıkış</translation>
    </message>
</context>
<context>
    <name>Settings.ui</name>
    <message>
        <location filename="../ui/Settings.ui.qml" line="28"/>
        <source>Settings</source>
        <translation>Ayarlar</translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="82"/>
        <source>Background Opacity:</source>
        <translation>Arkaplan Saydamlığı:</translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="106"/>
        <source>District:</source>
        <translation>İlçe:</translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="141"/>
        <source>Warn before mins:</source>
        <translation>Dakika kala uyar:</translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="152"/>
        <source>City:</source>
        <translation>Şehir:</translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="173"/>
        <source>Country:</source>
        <translation>Ülke:</translation>
    </message>
    <message>
        <location filename="../ui/Settings.ui.qml" line="233"/>
        <source>Save</source>
        <translation>Kaydet</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="170"/>
        <source>to Fajr</source>
        <translation>Sabah&apos;a</translation>
    </message>
    <message>
        <location filename="../main.qml" line="172"/>
        <source>to Sunrise</source>
        <translation>Güneş&apos;e</translation>
    </message>
    <message>
        <location filename="../main.qml" line="174"/>
        <source>to Dhuhr</source>
        <translation>Öğle&apos;ye</translation>
    </message>
    <message>
        <location filename="../main.qml" line="176"/>
        <source>to Asr</source>
        <translation>İkindi&apos;ye</translation>
    </message>
    <message>
        <location filename="../main.qml" line="178"/>
        <source>to Maghrib</source>
        <translation>Akşam&apos;a</translation>
    </message>
    <message>
        <location filename="../main.qml" line="180"/>
        <source>to Isha</source>
        <translation>Yatsı&apos;ya</translation>
    </message>
</context>
</TS>
